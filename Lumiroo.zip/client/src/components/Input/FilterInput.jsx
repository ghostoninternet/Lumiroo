import React from 'react'

function FilterInput() {
  return (
    <div>FilterInput</div>
  )
}

export default FilterInput