import React from 'react'

function PlaygroundInfoCard() {
  return (
    <div>PlaygroundInfoCard</div>
  )
}

export default PlaygroundInfoCard