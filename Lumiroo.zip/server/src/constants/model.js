const GENDER = {
  MALE: 'male',
  FEMALE: 'female',
  OTHER: 'other',
}

const ROLE = {
  ADMIN: 'admin',
  USER: 'user',
}

module.exports = {
  GENDER,
  ROLE,
}